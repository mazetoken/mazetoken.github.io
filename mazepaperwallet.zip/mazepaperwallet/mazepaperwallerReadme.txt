## MAZE Paper Wallet v.01

Use this wallet offline

More paper wallet's templates are coming soon

Maze Paper Walet Offline can be used for other SLP tokens too

Open mazepaperwallet.html in your browser to generate a new paper wallet

Scan public key QR code and send tokens to paper wallet

Scan private key QR code with sweep wallet/address option to receive tokens