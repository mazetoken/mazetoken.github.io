/* */
#include <sys/endian.h>


int main(void){return 0;}

