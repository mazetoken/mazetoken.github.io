/* */
#include <byteswap.h>


int main(void){return 0;}

