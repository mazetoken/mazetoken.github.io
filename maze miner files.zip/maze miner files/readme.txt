MAZE TOKEN miner files

Download your favourite miner

Replace files in the miner with Maze miner files

. env
generateV1.ts

Paste your WIF to .env

You don't need to replace generateV1.ts file if you don't want to (there is only name change from Mist to Maze)

Run commands:
npm i
npm audit fix (if you need to)
npm run tsc (if you need to)
npm start
